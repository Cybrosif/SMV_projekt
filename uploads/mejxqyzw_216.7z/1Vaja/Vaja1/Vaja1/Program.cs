﻿using System;

namespace Vaja1
{
    public class Kvadrat1
    {
        public double Stranica;

        public double IzracunajPloscino() => Stranica * Stranica;

        public double IzracunajObseg() => 4 * Stranica;
    }

    public class Kvadrat2
    {
        private double Stranica;

        public void NastaviStranico(double stranica)
        {
            Stranica = stranica < 0 ? 0 : stranica;
        }

        public double IzracunajPloscino() => Stranica * Stranica;

        public double IzracunajObseg() => 4 * Stranica;
    }

    public class Denarnica
    {
        private double stanje;

        public Denarnica() => stanje = 0;

        public Denarnica(Denarnica d) => stanje = d.stanje;

        public Denarnica(double zacetnoStanje) => stanje = zacetnoStanje < 0 ? 0 : zacetnoStanje;

        public bool Dvig(double vsota)
        {
            if (vsota <= stanje)
            {
                stanje -= vsota;
                return true;
            }
            return false;
        }

        public void Polog(double vsota)
        {
            if (vsota > 0)
                stanje += vsota;
        }

        public double VrniStanje() => stanje;
    }

    public class Semafor
    {
        private enum Luci { Rdeca, Zelena, Oranzna }
        private Luci trenutnaLuc;

        public void PrizgiRdeco() => trenutnaLuc = Luci.Rdeca;

        public void PrizgiZeleno() => trenutnaLuc = Luci.Zelena;

        public void PrizgiOranzno() => trenutnaLuc = Luci.Oranzna;

        public string IzpisLuci() => trenutnaLuc.ToString();

        public bool LahkoPrecasCesto() => trenutnaLuc == Luci.Zelena;
    }

    public class Stevec
    {
        private int vrednost;

        public Stevec() => vrednost = 0;

        public Stevec(int v) => vrednost = v;

        public Stevec(Stevec s) => vrednost = s.vrednost;

        public void Povecaj() => vrednost++;

        public void Zmanjsaj() => vrednost--;

        public int IzpisVrednosti() => vrednost;
    }

    public class Datum
    {
        private int dan, mesec, leto;

        public Datum()
        {
            dan = 1;
            mesec = 1;
            leto = 2000;
        }

        public Datum(int d, int m, int l)
        {
            if (JeVeljavenDatum(d, m, l))
            {
                dan = d;
                mesec = m;
                leto = l;
            }
            else
            {
                dan = 0;
                mesec = 0;
                leto = 0;
            }
        }

        private bool JeVeljavenDatum(int d, int m, int l) => d > 0 && d <= 31 && m > 0 && m <= 12;

        public string IzpisDatum() => $"{dan}.{mesec}.{leto}";
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            Kvadrat1 k1 = new Kvadrat1 { Stranica = 5 };
            Console.WriteLine($"Kvadrat1 Ploscina: {k1.IzracunajPloscino()}, Obseg: {k1.IzracunajObseg()}");

            Kvadrat2 k2 = new Kvadrat2();
            k2.NastaviStranico(5);
            Console.WriteLine($"Kvadrat2 Ploscina: {k2.IzracunajPloscino()}, Obseg: {k2.IzracunajObseg()}");

            Denarnica d = new Denarnica();
            d.Polog(100);
            Console.WriteLine($"Stanje po pologu: {d.VrniStanje()}");
            d.Dvig(50);
            Console.WriteLine($"Stanje po dvigu: {d.VrniStanje()}");

            Semafor s = new Semafor();
            s.PrizgiZeleno();
            Console.WriteLine($"Trenutna luc: {s.IzpisLuci()}, Lahko preckamo cesto: {s.LahkoPrecasCesto()}");

            Console.ReadLine();
        }
    }
}
